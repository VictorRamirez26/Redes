<!DOCTYPE html>
<html lang="es">
	<head>
		<meta charset="utf-8">
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<meta http-equiv="Cache-Control" content="no-cache, no-store, must-revalidate">
		<meta http-equiv="Pragma" content="no-cache">
		<meta http-equiv="Expires" content="0">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<title>¡Raspá y ganá $30.000! | Terminos y Condiciones | Banco Patagonia</title>
		<meta name="description" content="Desde el 10 al 17 de mayo, a través de Patagonia Móvil vas a poder participar por hasta $30.000.">
		<!-- Google Tag Manager -->
<script>(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':
new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],
j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src=
'https://www.googletagmanager.com/gtm.js?id='+i+dl;f.parentNode.insertBefore(j,f);
})(window,document,'script','dataLayer','GTM-NL73B44');</script>
<!-- End Google Tag Manager -->

<link rel="shortcut icon" href="../favicon.ico" type="image/x-icon"/>
<link href="../assets/fonts/font-awesome-4.7.0/css/font-awesome.min.css" rel="stylesheet" type="text/css">
<link href="../assets/bootstrap/css/bootstrap.min.css" rel="stylesheet" type="text/css">
<link href="../assets/js/mtabs/bootstrap-responsive-tabs.css" rel="stylesheet" type="text/css">
<link href="../assets/js/slick/slick.css" rel="stylesheet" type="text/css">
<link href="../assets/js/fancybox/jquery.fancybox.min.css" rel="stylesheet" type="text/css">
<link href="../assets/css/styles.css" rel="stylesheet" type="text/css">
<!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
<!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
<!--[if lt IE 9]>
<script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
<script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
<![endif]-->		
		<!-- SLIDES RESPONSIVE -->
		<style>
			/* DSK */
			#head-raspa-y-gana {background-image: url(images/head-raspa-y-gana-dsk-2.jpg)}

			@media screen and (max-width: 1200px) {
				/* TBT */
				#head-raspa-y-gana {background-image: url(images/head-raspa-y-gana-tbl-2.jpg); background-size: auto !important ;}
			}
			@media screen and (max-width: 560px) {
				/* MBL */
				#head-raspa-y-gana {background-image: url(images/head-raspa-y-gana-mbl-2.jpg)}
			}
		</style>
		<!-- -->

		<style>
			h1 span { font-family: "Roboto-Regular"; }
		</style>
		
	</head>
<body>
	<!--<php include($path . "includes/header_inc.php"); ?>-->
	<section class="sec-head" title="¡Probá tu suerte y a cruzar los dedos!">
        <div class="sec-pic-head" id="head-raspa-y-gana">
        </div>
	</section>
	<section class="container">
		<div class="row">
			<div class="col-md-12 col-sm-12 col-xs-12">
				<ol class="breadcrumb">
					<li>Raspá y Ganá</li>
                    <li class="active">Terminos y Condiciones</li>
				</ol>
			</div>
		</div>
	</section>
	<section class="container">
		<div class="row">
            <div class="col-md-12 col-sm-12 col-xs-12">
                <div class="text-data">
                    <!-- -->
                    <h1 style="line-height: 1.2em; margin-bottom: 10px;">Raspá y Ganá</h1>
                    <h2>Terminos y Condiciones &ldquo;Raspá y Ganá JUNIO&rdquo;</h2>
                    <!-- -->
					<br>
                    <p>Promoción. Territorio. Vigencia.
‌

Banco Patagonia S.A. (el “Organizador”), CUIT 30-50000661-3, con domicilio legal en Avenida de Mayo 701, Piso 24, Ciudad Autónoma de Buenos Aires (C1084AAC), organiza la promoción “Raspá y Ganá JUNIO” (la “Promoción”), la cual estará regida por los presentes términos y condiciones (“T&C”).

La Promoción tendrá validez dentro de la República Argentina, excepto para residentes de las provincias de Tierra del Fuego, Río Negro, Mendoza, Neuquén, Jujuy, Córdoba y Salta (el “Territorio”) desde el 01 de junio de 2024 a las 9:00 hs. hasta el 10 de junio de 2024 a las 23:59 hs., ambas fechas y horarios incluidos (la "Vigencia") o hasta que se adjudiquen los Premios indicados en la sección 5 de los presentes T&C, lo que ocurra primero. La Vigencia es improrrogable.

‌

‌

‌
Requisitos para ser Participante.

‌

Podrán participar en esta Promoción las personas que cumplan con los siguientes requisitos durante la Vigencia y/o hasta agotar el stock indicado en la sección 5.5., inclusive (en adelante, el “Participante” o los “Participantes”):

‌

2.1 Participantes Clientes: podrán participar las personas humanas que cumplan con todos estos requisitos: (i) sean mayores de 18 (dieciocho) años y posean capacidad legal para contratar en el Territorio, (ii) posean domicilio en el Territorio, (iii) sean usuarios del Organizador y hayan descargado la última versión de la aplicación Patagonia Móvil del Organizador (la “App”) con la correspondiente aceptación de sus Términos y Condiciones en la App, (iv) realicen 1 (un) pago mediante lectura del código QR (“Pago con QR” o “Transacción”) de proveedores de bienes y servicios -debidamente registrados como tal- a través de la App y de acuerdo a lo establecido en la sección 3 y (v) no mantengan ninguna deuda o se encuentren en incumplimiento de cualquier obligación con el Organizador.

‌

2.2. Participantes No Clientes: personas humanas mayores de 18 (dieciocho) años legalmente capaces, domiciliados dentro del Territorio, que cumplan con la sección 4 de estos T&C.

‌

2.3 No podrán participar de la Promoción: (i) personas jurídicas; (ii) personas con domicilio fuera del Territorio; y/o (iii) participantes que no cumplan con estos T&C.

‌

‌

Mecánica de la Promoción y modo de participación.
‌

3.1. Durante la Vigencia de la Promoción, el Participante Cliente que realice exitosamente un Pago con QR por un monto igual o superior a tres mil pesos ($3000), tendrá la posibilidad de participar de la Promoción descubriendo el Premio oculto detrás de cada cupón que le aparecerá en la App luego del Pago con QR. Para ello, deberá deslizar con el dedo sobre el cupón que aparecerá en la pantalla y cumplir con todos los requisitos previstos en estos T&C.

No se acreditarán Premios a aquellos Pagos con QR que fueran posteriormente cancelados, autopagos, ni tampoco a pagos recurrentes al mismo comercio.

‌

3.2. Los potenciales ganadores se determinarán en base a un sistema que aleatoriamente seleccionará aquellas participaciones que hayan sido registradas de manera completa en función de las probabilidades matemáticas de adjudicación de premios establecidas.

‌

3.3. Las probabilidades de resultar ganador de un Premio (según se definen y detallan más adelante) dependerán de la cantidad de participaciones que se realicen a lo largo de la Vigencia.

‌

3.5. El Participante Cliente podrá ganar hasta un máximo de 3 (tres) Premios por día durante la Vigencia.

‌

‌

Participación sin obligación de compra
‌

Los Participantes No Clientes que deseen participar de la Promoción y cumplan con todos los requisitos previstos en la sección 2.2 deberán enviar a la casilla de correo raspaygana@bancopatagonia.com.ar, una copia o scan de un dibujo a mano alzada y con colores del logo del Organizador junto a sus datos personales, a saber: nombre y apellido, domicilio completo (calle, número, piso y departamento si corresponde, ciudad, localidad, provincia y código postal), tipo y número de documento nacional de identidad, edad, número telefónico anteponiendo el código de área correspondiente, dirección de correo electrónico y CBU de la cuenta bancaria de Banco Patagonia. A su vez, en el asunto del correo electrónico deberá indicarse la leyenda “Raspá y Ganá Junio”. En función del horario de recepción del correo con la participación sin obligación de compra, para el supuesto que se reúnan todas las condiciones de la presente, el Organizador ingresará manualmente los datos del Participante No Cliente al procedimiento informático de selección aleatoria y participará de la Promoción en igualdad de condiciones y con las probabilidades indicadas en el punto 4.2. de estos Términos y Condiciones. El Organizador informará al participante dentro de las 48 horas si resultó beneficiado con algún Premio y en su caso cuál. Solicitándole los datos de una cuenta bancaria (CBU) en la que el Organizador procederá a transferir el Premio adjudicado. La falta de indicación de tal cuenta dentro de las 48 horas de recibido el correo por parte del Organizador, hará perder cualquier derecho al Premio el cual quedará en poder del Organizador. La acreditación del Premio por parte del Organizador deberá realizarse en la cuenta bancaria informada dentro de un plazo no mayor a quince (15) días hábiles. Las participaciones que no cumplan con todos estos requisitos serán descalificadas automáticamente, sin necesidad de informar tal situación a los interesados. Los datos personales de los Participantes Sin Obligación de Compra serán únicamente utilizados a los fines de participar de la Promoción y no serán utilizados para ningún otro fin.

‌

‌

Premios. Probabilidad matemática de resultar ganador. Entrega de Premios.
‌

5.1. Los Premios son cupones con un importe en pesos que se acreditará en la cuenta bancaria del Participante ganador conforme se describe más adelante.

El programa total de beneficios en el marco de la Promoción (los “Premios”) será el siguiente: 1340 cupones de $500 (pesos quinientos) cada uno; 210 cupones de $800 (pesos ochocientos) cada uno; 58 cupones de $1.000 (pesos mil) cada uno; y 8 de $30.000 (pesos treinta mil) cada uno.

La cantidad máxima de los Premios a asignar a todos los Participantes en su conjunto y por toda la Vigencia asciende a la suma de 1616 Premios y por un total de $1.136.000 pesos un millón ciento treinta y seis)

‌

5.2. Por cada Transacción, las probabilidades de resultar ganador de un Premio para los Participantes Clientes que ya hayan realizado Pagos con QR desde Patagonia Móvil será de un 15% en el primer pago. Para aquellos Participantes Clientes que realicen su primera Transacción durante la Vigencia -es decir, que nunca hayan realizado un Pago con QR desde Patagonia Móvil previamente- dicha probabilidad se eleva al 100%.

‌

5.3. Cada Premio es personal e intransferible y el Participante ganador no podrá solicitar su reemplazo por otros bienes o servicios como tampoco por dinero en efectivo, ni la cesión de éste a ningún tercero.

‌

5.4. De encontrarse el Participante ganador en cumplimiento con lo previsto en estos T&C, el Organizador acreditará el Premio obtenido dentro de los quince (15) días hábiles en la cuenta bancaria principal asociada a la App Patagonia Móvil por el Participante Cliente o bien en la cuenta bancaria o virtual de su titularidad que el Participante no Cliente hubiera indicado según lo señalado en la sección 4.

‌

5.5. En caso de que, por cualquier motivo, la cuenta del Participante referida en la sección 5.4 no sea válida para la acreditación del Premio y el Participante no provea una cuenta alternativa de su titularidad dentro del plazo de perentorio de 72 (setenta y dos) horas de requerido por el Organizador mediante contacto telefónico o vía correo electrónico o WhatsApp, el Participante en cuestión perderá automáticamente todo derecho al Premio y el mismo quedará en propiedad del Organizador.

‌

5.6. Los Premios no asignados a la finalización del Plazo de la Promoción, si los hubiere, quedarán en poder del Organizador o de quien éste designe a tal fin.

‌

‌

Otras condiciones.
‌

6.1. La sola participación en la Promoción implica la aceptación expresa de estos T&C, como así también el reconocimiento de que las decisiones que el Organizador tome con relación a la Promoción tendrán carácter definitivo e inapelables siempre que ellas sean debidamente comunicadas, no resulten abusivas ni infundadas, no perjudiquen dolosamente el derecho de los/as participantes y respeten la legislación aplicable.

‌

6.2. Todo gasto e impuesto, tasa o contribución en el que deban incurrir los Participantes con motivo de la participación en la Promoción y/o la asignación y/o cobro del Premio serán a cargo de éstos exclusivamente. En tal sentido, y a fin de despejar cualquier duda, se aclara que única y exclusivamente estarán a cargo del Organizador aquellos premios, adicionales, pagos o gestiones que estén expresamente indicados en este reglamento como a cargo del Organizador.

‌

6.3. El Organizador podrá suspender la acreditación de Premios o acceso a la cuenta de cualquier Participante en cualquier momento cuando, a criterio exclusivo del Organizador, existieran sospechas de ilegalidad, fraude o incumplimiento de los T&C, sin perjuicio de los demás reclamos, acciones legales o denuncias que pudieran corresponder. Particularmente, el Organizador se reserva el derecho a limitar, prohibir la participación o suspender la cuenta de cualquier Participante y/o el otorgamiento del Premio en caso de presumir la existencia de trampas, engaños, fraude o alteración en la mecánica de participación destinada a ganar de forma ilegítima, sin asumir responsabilidad alguna frente a tales personas, usuarios o terceros. El Organizador no se responsabilizará ni otorgará indemnización alguna, contractual y/o extracontractual, bajo ningún concepto, como así tampoco será responsable del destino de los Premios ni por el daño personal o material o pérdida (directa, indirecta y/o consecuente) ocasionado a los Participantes y/o a terceros, incluyendo a aquellos que hagan uso del Premio.

‌

6.4. El Organizador no será responsable: (i) por ningún daño o perjuicio, de cualquier tipo que fuere, que pudiere sufrir el Participante o terceros, sobre sus personas o bienes, con motivo de o en relación con su participación en la presente Promoción y/o la asignación de los Premios; y/o (ii) por fallas y/o desperfectos técnicos y/o por errores humanos o acciones deliberadas de terceros que pudieran interrumpir o alterar el desarrollo de la Promoción.

‌

6.5. El Organizador no será responsable por pérdidas de información, interrupciones o incapacidades de la red, internet y/o cualquier servidor, fallas en las transmisiones de las líneas telefónicas o fallas técnicas a la hora de la participación en la Promoción y/o acreditación del Premio, sean ellas provenientes de un error de tipo humano, mecánico o electrónico que pudieren afectar total o parcialmente la participación en la Promoción y/o la adjudicación del Premio y/o la recepción de la comunicación a los Participantes que resulten ganadores.

‌

6.6. El Organizador podrá ampliar la cantidad de Premios ofrecidos o la Vigencia de la Promoción.

‌

‌

Datos personales
‌

Los Datos requeridos a los/las Participantes fueron solicitados conforme lo dispuesto por Ley 25.326 y sus normas modificatorias y complementarias y serán utilizados y conservados por el Organizador de conformidad con lo dispuesto en las Políticas de Privacidad del Organizador disponibles en Banco Patagonia

Asimismo, y en cumplimiento de la Ley de Protección de Datos Personales (Ley 25.326), el/la Participante podrá ratificar, rectificar o suprimir la información brindada comunicándose al 0810 888 8500 de lunes a viernes de 9 a 19 hs o remitiendo un mail a atencionclientes@bancopatagonia.com.ar

El/la titular de los datos personales tiene la facultad de ejercer el derecho de acceso a los mismos en forma gratuita y en intervalos no inferiores a seis meses, salvo que se acredite un interés legítimo al efecto, conforme lo establecido en el artículo 14, inciso 3 de la Ley 25.326. La DIRECCIÓN NACIONAL DE PROTECCIÓN DE DATOS PERSONALES, Órgano de Control de la Ley 25.326, tiene la atribución de atender las denuncias y reclamos que se interpongan con relación al incumplimiento de las normas sobre protección de datos personales.

Banco Patagonia S.A. asume el carácter de Responsable Registrado ya que ha cumplimentado con todos los requisitos que exige esta ley.

Finalmente queda establecido que los datos obtenidos de la presente Promoción no serán utilizados para un fin distinto que el establecido en estos T&C.

‌

‌

Suspensión, Modificación y Cancelación
‌

El Organizador de la presente Promoción se reserva el derecho de establecer y pronunciarse sobre aquellas situaciones o circunstancias que no estén expresamente previstas en estos T&C, reservándose asimismo el derecho a cancelar, suspender o modificar la Promoción por circunstancias no previstas ajenas a la voluntad del Organizador, aclarándose que, cualquiera de las situaciones mencionadas será ajustada a la legislación vigente en la materia y debidamente comunicadas a los/as Participantes.

‌

Las partes prestan conformidad para que toda divergencia que pudiera surgir con relación a la Promoción y a los efectos de ésta sea sometida al derecho argentino y a la jurisdicción y competencia de los Tribunales Ordinarios del fuero Comercial de la Ciudad Autónoma de Buenos Aires, renunciando a cualquier otro fuero y jurisdicción que pudiera corresponderles.
‌

‌

10. Los accionistas de BANCO PATAGONIA S.A. (CUIT: 30-50000661-3, Av. de Mayo 701 Piso 24 (C1084AAC), Ciudad Autónoma de Buenos Aires) limitan su responsabilidad a la integración de las acciones suscriptas. En virtud de ello, ni los accionistas mayoritarios de capital extranjero ni los accionistas locales o extranjeros, responden en exceso de la citada integración accionaria por las obligaciones emergentes de las operaciones concertadas por la entidad financiera (Ley 25.738).

‌</p>
                    <!-- -->
                </div>
            </div>
		</div>
	</section>
    <!--<php include($path . "includes/footer_inc.php"); ?>-->
	<script src="../assets/js/jquery-3.5.1.min.js"></script>
<script src="../assets/bootstrap/js/bootstrap.min.js"></script>
<script src="../assets/js/slick/slick.min.js"></script>
<script src="../assets/js/fancybox/jquery.fancybox.min.js"></script>
<script src="../assets/js/mtabs/jquery.bootstrap-responsive-tabs.min.js"></script>
<script src="../assets/js/funciones.js"></script>

<!-- Global site tag (gtag.js) - Google Analytics (original) -->
<!--
<script async src="https://www.googletagmanager.com/gtag/js?id=UA-32588129-1"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'UA-32588129-1');
</script>
-->

<!-- Google Analytics (version anterior / eventos ok)  -->
<script>
  (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
  (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
  m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
  })(window,document,'script','//www.google-analytics.com/analytics.js','ga');
  ga('create', 'UA-32588129-1', 'auto');
  ga('send', 'pageview');
</script>

<!-- GA4 - Google tag (gtag.js) -->
<script async src="https://www.googletagmanager.com/gtag/js?id=G-C6LG1PT98X"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'G-C6LG1PT98X');
</script>
</body>
</html>